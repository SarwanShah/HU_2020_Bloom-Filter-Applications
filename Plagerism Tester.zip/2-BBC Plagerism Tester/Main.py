from filterFileHandler import *
from BloomFilter import *


#Generate a filter from a database file and input it to a 
exampleFilter = generateFilterFile('BBCTextCleaned.txt', 'MainFilterFile.txt', 0.001)
#exampleFilter = loadFilterFile('MainFilterFile-43407-1-10-624088.txt')
# Let us check
fileCheck('SampleDoc.txt', exampleFilter)


def fileCheck(inputFile, Filter):
    count = 0
    matches = 0
    file = open(inputFile)

    for i, l in enumerate(file):  pass
    length = i + 2
    file.seek(0)
    
    for line in range(0, length):
        data = (file.readline()).strip()
        if Filter.check(data): matches += 1
        count += 1

    print(count, matches)
    print('Document was about ' + str((matches/count)*100) + '% plagerised')
