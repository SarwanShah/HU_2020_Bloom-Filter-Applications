import re

uncleanText = open("blah.txt").read()
cleanText = re.sub(r"[^a-zA-Z\n]+", ' ', uncleanText)
#open('clean.txt', 'w+').write(cleanText)

file = open('cleanedblah.txt', 'w')
lst = cleanText.split('.')
for line in lst:
    if len(line) != 0:
        file.write(line.strip()+'\n')

file.close()


